-- *************************************************************************************************
-- This script creates all of the database objects (tables, sequences, etc) for the database
-- *************************************************************************************************

BEGIN;

CREATE SEQUENCE seq_appUserId;

CREATE TABLE appUser
(
	appUserId INTEGER PRIMARY KEY DEFAULT NEXTVAL('seq_appUserId'),
	username VARCHAR(30) NOT NULL,
	password VARCHAR(30) NOT NULL,
	email VARCHAR(30) NOT NULL,
	isSystemAdmin boolean NOT NULL
);

CREATE SEQUENCE seq_plotId;

CREATE TABLE plot
(
	plotId INTEGER PRIMARY KEY DEFAULT NEXTVAL('seq_plotId'),
	name VARCHAR(30) NOT NULL,
	region_id INTEGER NOT NULL,
	sunExposure INTEGER NOT NULL,
	height INTEGER NOT NULL,
	width INTEGER NOT NULL
);

CREATE TABLE appUser_plot
(
	appUserId INTEGER NOT NULL,
	plotId INTEGER NOT NULL,
	CONSTRAINT pk_appUser_plot PRIMARY KEY (appUserId, plotId)
);

CREATE SEQUENCE seq_squareId;

CREATE TABLE square
(
	squareId INTEGER PRIMARY KEY DEFAULT NEXTVAL('seq_squareId'),
	plantId INTEGER
);

CREATE TABLE plot_square
(
	plotId INTEGER NOT NULL,
	squareId INTEGER NOT NULL,
	
	CONSTRAINT pk_plot_square PRIMARY KEY (plotId, squareId)
);

CREATE SEQUENCE region_region_id_seq;

CREATE TABLE region (
	region_id integer PRIMARY KEY DEFAULT nextval('region_region_id_seq'),
	region_name varchar(150) NOT NULL
);

CREATE SEQUENCE plant_types_plant_type_id_seq;

CREATE TABLE plant_types (
	plant_type integer PRIMARY KEY DEFAULT nextval('plant_types_plant_type_id_seq'),
	type_description varchar(75) NOT NULL,
	default_image varchar(75) NOT NULL,
	price money NOT NULL
);

CREATE SEQUENCE plant_plant_id_seq;

CREATE TABLE plant (
	plant_id integer PRIMARY KEY DEFAULT nextval('plant_plant_id_seq'),
	botanical_name varchar(75) NOT NULL,
	common_name varchar(50) NOT NULL,
	plant_type int NOT NULL,
	spread int NOT NULL,
	height int NULL,
	min_sun int NULL,
	max_sun int NULL
);

CREATE TABLE plant_region (
	plant_id int,
	region_id int,
	CONSTRAINT pk_plantregion PRIMARY KEY (plant_id, region_id)
);

ALTER TABLE appUser_plot ADD CONSTRAINT fk_appUser_plot_appUser FOREIGN KEY (appUserId) REFERENCES appUser (appUserId);
ALTER TABLE appUser_plot ADD CONSTRAINT fk_appUser_plot_plot FOREIGN KEY (plotId) REFERENCES plot (plotId);
ALTER TABLE square ADD CONSTRAINT fk_square_plants FOREIGN KEY (plantId) REFERENCES plant (plant_id);
ALTER TABLE plot_square ADD CONSTRAINT fk_plot_square_plot FOREIGN KEY (plotId) REFERENCES plot (plotId);
ALTER TABLE plot_square ADD CONSTRAINT fk_plot_square_square FOREIGN KEY (squareId) REFERENCES square (squareId);
ALTER TABLE plot ADD CONSTRAINT fk_plot_region FOREIGN KEY (region_id) REFERENCES region (region_id);

COMMIT;