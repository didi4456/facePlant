package com.techelevator.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.techelevator.model.ShoppingCart;
import com.techelevator.model.User;
import com.techelevator.model.UserDao;

@Controller
@Transactional
@SessionAttributes("currentUser")
public class AuthenticationController {
	
	private UserDao userDao;

	@Autowired
	public AuthenticationController(UserDao userDao) {
		this.userDao = userDao;
	}
	
	@RequestMapping(path="/", method=RequestMethod.GET)
	public String displayHomePage(ModelMap model) {
		if(model.get("currentUser")!=null) {
			User user = (User)model.get("currentUser");
			return "redirect:/user/"+user.getUsername();
		} else {
			return "homePage";
		}
	}
	
	@RequestMapping(path="/login", method=RequestMethod.GET)
	public String displayLoginForm() {
		return "login";
	}
	
	@RequestMapping(path="/login", method=RequestMethod.POST)
	public String login(@RequestParam String username, 
						@RequestParam String password, 
						ModelMap model,
						HttpSession session) {
		if(userDao.searchForUsernameAndPassword(username, password)) {
			session.invalidate();
			User currentUser = userDao.getUserByUsername(username);
			currentUser.setShoppingCart(new ShoppingCart());
			model.put("currentUser", currentUser);
			return "redirect:/user/"+username;
		} else {
			return "redirect:/login";
		}
	}

	@RequestMapping(path="/logout", method=RequestMethod.POST)
	public String logout(ModelMap model, HttpSession session) {
		model.remove("currentUser");
		session.removeAttribute("currentUser");
		//session.invalidate();
		return "redirect:/";
	}
	
	@RequestMapping(path="/register", method=RequestMethod.GET)
	public String registerUser(){
		return "register";
	}
	
	@RequestMapping(path="/register", method=RequestMethod.POST)
	public String registerUser(@RequestParam String username,
							@RequestParam String password,
							@RequestParam String email,
							HttpSession session,
							ModelMap model) {
		if(userDao.getUserByUsername(username) == null) {
			session.invalidate();
			userDao.createNewUser(username, password, email, false);
			model.put("currentUser", userDao.getUserByUsername(username));
			return "redirect:/user/"+username;
		} else {
			return "redirect:/register";
		}
	}
}