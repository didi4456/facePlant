package com.techelevator.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
	public class FooterController {

		@RequestMapping(path="/teamDelta", method=RequestMethod.GET)
		public String displayTeamDeltaPage(ModelMap model) {
			return "teamDelta";
		}
		@RequestMapping(path="/aboutFacePlant", method=RequestMethod.GET)
		public String displayAboutFacePlant() {
			return "aboutFacePlant";
		}
		@RequestMapping(path="/resources", method=RequestMethod.GET)
		public String displayResources() {
			return "resources";
		}
}
