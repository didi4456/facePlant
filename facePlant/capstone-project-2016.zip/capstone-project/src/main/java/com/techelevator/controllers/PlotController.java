package com.techelevator.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.techelevator.model.Plant;
import com.techelevator.model.PlantDao;
import com.techelevator.model.Plot;
import com.techelevator.model.PlotDao;

//@RestController
@Controller
@Transactional
@SessionAttributes("currentUser")
public class PlotController {
	
	private PlotDao plotDao;
	private PlantDao plantDao;

	@Autowired
	public PlotController(PlotDao plotDao, PlantDao plantDao) {
		this.plotDao = plotDao;
		this.plantDao = plantDao;
	}
	
	@RequestMapping(path="/user/{username}/{plotId}/recommendedPlants", method=RequestMethod.GET)
	public @ResponseBody List<Plant> getRecommendedPlants(@PathVariable long plotId) {
		Plot plot = plotDao.getPlotById(plotId);
		return plantDao.getPlantRecommendationByPlotDetails(plot.getRegion(), plot.getSunExposure());
	}
}
