package com.techelevator.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.techelevator.model.Plant;
import com.techelevator.model.PlantDao;
import com.techelevator.model.PlantQuantity;
import com.techelevator.model.Plot;
import com.techelevator.model.ShoppingCart;
import com.techelevator.model.User;

@Controller
@Transactional
@SessionAttributes("currentUser")
public class ShoppingCartController {
	
	private PlantDao plantDao;
	private ShoppingCart cart;
	
	@Autowired
	public ShoppingCartController(PlantDao plantDao) {
		this.plantDao = plantDao;
	}
	
	@RequestMapping(path="/user/{username}/viewShoppingCart", method=RequestMethod.GET)
	public String viewShoppingCart(ModelMap model) {
		ShoppingCart shoppingCart = ((User)model.get("currentUser")).getShoppingCart();
		model.addAttribute("shoppingCart",shoppingCart);
		return "shoppingCart";
	}
	
	@RequestMapping(path="/user/{username}/addToShoppingCart", method=RequestMethod.POST)
	public String addToCart(@RequestParam int quantity, @RequestParam Long plantId, ModelMap model) {
		
		ShoppingCart cart = ((User)model.get("currentUser")).getShoppingCart();
		Plant plant = plantDao.getPlantById(plantId);
		PlantQuantity plantQuantity = new PlantQuantity(plant, quantity);
		cart.addToCart(plantQuantity);
		
		return "redirect:/user/{username}/viewShoppingCart";
	}
	
	@RequestMapping(path="/user/{username}/updateQuantity", method=RequestMethod.POST)
	public String updateQuantityInPlantQuantity(@RequestParam String plantName,
												@RequestParam int quantity,
												ModelMap model) {
		ShoppingCart cart = ((User)model.get("currentUser")).getShoppingCart();
		PlantQuantity plantQuantity = cart.findPlantQuantityByCommonName(plantName);
		cart.updateQuantityInPlantQuantity(plantQuantity, quantity);
		return "redirect:/user/{username}/viewShoppingCart";
	}

	
	@RequestMapping(path="/user/{username}/mulchTopsoilCalculator", method=RequestMethod.GET)
	public String updateMulchAndSoilSuggestion(@RequestParam(required=false) Integer plotHeight, @RequestParam(required=false) Integer plotWidth,
												@RequestParam(required=false) Integer topsoilDepthInInches,@RequestParam(required=false) Integer mulchDepthInInches, @RequestParam(required=false) Boolean fromForm, ModelMap model) {
	 
		if (fromForm!=null){
		double totalMulch= Plot.getMulch(plotHeight,plotWidth,mulchDepthInInches);
		double totalTopsoil=Plot.getTopsoil(plotHeight,plotWidth,topsoilDepthInInches);
		int bagsOfMulch=Plot.getBagsOfMulch(totalMulch);
		int bagsOfTopsoil=Plot.getBagsOfTopsoil(totalTopsoil);
		model.addAttribute("mulch",totalMulch);
		model.addAttribute("topsoil", totalTopsoil);
		model.addAttribute("bagsOfMulch", bagsOfMulch);
		model.addAttribute("bagsOfTopsoil", bagsOfTopsoil);
		
		}
		return "mulchTopsoilCalculator";
	
	}

}
