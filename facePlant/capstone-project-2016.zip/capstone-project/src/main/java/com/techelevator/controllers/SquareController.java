package com.techelevator.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.techelevator.model.Square;
import com.techelevator.model.SquareDao;

@Controller
@Transactional
public class SquareController {

	private SquareDao squareDao;

	@Autowired
	public SquareController(SquareDao squareDao) {
		this.squareDao = squareDao;
	}

	@RequestMapping(path="/user/{username}/{plotId}/{squareId}", method=RequestMethod.GET)
	public @ResponseBody Square getSquare(@PathVariable String username,
									@PathVariable long plotId,
									@PathVariable long squareId,
									ModelMap model) {
		Square square = squareDao.getSquareById(squareId);
		return square;
	}
	
	@RequestMapping(path="/user/{username}/{plotId}/{squareId}/{plantId}", method=RequestMethod.POST)
	public @ResponseBody Square addPlantToSquare(@PathVariable String username,
											@PathVariable long plotId,
											@PathVariable long squareId,
											@PathVariable long plantId,
											ModelMap model) {
		squareDao.addPlantToSquare(squareId, plantId);
		return squareDao.getSquareById(squareId);
	}
	
	@RequestMapping(path="/user/{username}/{plotId}/{squareId}/empty", method=RequestMethod.POST)
	public @ResponseBody Square emptySquare(@PathVariable String username,
											@PathVariable long plotId,
											@PathVariable long squareId,
											ModelMap model) {
		squareDao.emptySquare(squareId);
		return squareDao.getSquareById(squareId);
	}
}
