package com.techelevator.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.techelevator.model.PlantDao;
import com.techelevator.model.User;
import com.techelevator.model.UserDao;

@Controller
@Transactional
@SessionAttributes("currentUser")
public class SystemAdminController {

	private UserDao userDao;
	private PlantDao plantDao;

	@Autowired
	public SystemAdminController(UserDao userDao, PlantDao plantDao) {
		this.userDao = userDao;
		this.plantDao = plantDao;
	}

	@RequestMapping(path="/user/{username}/systemAdmin", method=RequestMethod.GET)
	public String displaySystemAdminPage(ModelMap model) {
		return "systemAdmin";
	}
	
	@RequestMapping(path="/user/{username}/systemAdmin/createNewAdmin", method=RequestMethod.POST)
	public String createNewAdmin(@RequestParam String username, @RequestParam String password,
			@RequestParam String email, HttpSession session, ModelMap model) {
		// if username isn't taken
		if (userDao.getUserByUsername(username) == null) {
			userDao.createNewUser(username, password, email, true);
			return "redirect:/user/"+((User)model.get("currentUser")).getUsername()+"systemAdmin";
		} else {
			return "redirect:/register";
		}
	}
	
	@RequestMapping(path="/user/{username}/systemAdmin/createPlant", method=RequestMethod.POST)
		public String createNewPlant(@RequestParam String plantName, @RequestParam String plantLatinName, 
										@RequestParam int plantType, @RequestParam int minSun, @RequestParam int maxSun, 
										@RequestParam int spread, @RequestParam int height, @RequestParam int region,
										ModelMap model) {
			if(plantDao.searchPlantByName(plantName)== null){
				plantDao.createNewPlantEntry(plantName, plantLatinName, plantType, spread, height, minSun, maxSun,region);
				return "redirect:/user/"+((User)model.get("currentUser")).getUsername()+"/systemAdmin";
			}else{
				return "redirect/user/{username}/systemAdmin";
			}
	}
	
//	@RequestMapping(path="/user/{username}/systemAdmin/editPlant", method=RequestMethod.POST)
//		public String editExistingPlant(ModelMap model) {
//			return "redirect:/user/"+((User)model.get("currentUser")).getUsername()+"systemAdmin";
//	}

}
