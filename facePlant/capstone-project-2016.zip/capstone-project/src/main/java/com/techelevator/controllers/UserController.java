package com.techelevator.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.techelevator.model.Plant;
import com.techelevator.model.PlantDao;
import com.techelevator.model.Plot;
import com.techelevator.model.PlotDao;
import com.techelevator.model.User;
import com.techelevator.model.UserDao;

@Controller
@Transactional
@SessionAttributes("currentUser")
public class UserController {

	private UserDao userDao;
	private PlotDao plotDao;
	private PlantDao plantDao;

	@Autowired
	public UserController(UserDao userDao, PlotDao plotDao, PlantDao plantDao) {
		this.userDao = userDao;
		this.plotDao = plotDao;
		this.plantDao = plantDao;
	}

	@RequestMapping(path="/user/{username}", method=RequestMethod.GET)
	public String displayUserPage(@PathVariable String username,
									ModelMap model) {
		User user = userDao.getUserByUsername(username);
		List<Plot> plotList = plotDao.getPlotsByUserId(user.getId());
		model.addAttribute("plotList", plotList);
		return "userPage";
	}
	
	@RequestMapping(path="/user/{username}/newPlot", method=RequestMethod.POST)
	public String submitNewPlot(@PathVariable String username,
								Plot plot,
								ModelMap model) {
		long id = userDao.getUserByUsername(username).getId();
		plotDao.createNewPlotForUserId(id, plot.getPlotName(), plot.getRegion(), plot.getSunExposure(), plot.getPlotHeight(), plot.getPlotWidth());;
		return "redirect:/user/{username}";
	}
	
	@RequestMapping(path="/user/{username}/{plotId}", method=RequestMethod.GET)
	public String displayPlot(@PathVariable String username,
								@PathVariable long plotId,
									ModelMap model) {
		model.addAttribute("username", username);
		Plot plot = plotDao.getPlotById(plotId);
		List<Plant> recommendedPlantsList = plantDao.getPlantRecommendationByPlotDetails(plot.getRegion(), plot.getSunExposure());
		model.addAttribute("recommendedPlantsList", recommendedPlantsList);
		model.addAttribute("plot", plot);
		return "plotDetail";
	}
}
