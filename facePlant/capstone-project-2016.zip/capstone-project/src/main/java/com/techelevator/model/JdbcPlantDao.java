package com.techelevator.model;

import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;

@Component
public class JdbcPlantDao implements PlantDao {
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public JdbcPlantDao(DataSource dataSource) {
		this.jdbcTemplate= new JdbcTemplate(dataSource);
	}

	@Override
	public List<Plant> getPlantRecommendationByPlotDetails(Long regionId, int sunExposure) {
		List <Plant> plantList = new ArrayList<Plant>();
		String sqlSelectPlantByPlotDetails = 	"SELECT * "+
												"FROM plant "+
												"JOIN plant_region ON plant.plant_id=plant_region.plant_id "+
												"JOIN region ON plant_region.region_id=region.region_id "+
												"JOIN plant_types ON plant_types.plant_type=plant.plant_type "+
												"WHERE region.region_id=? AND (min_sun IS NULL OR min_sun <= ?) AND (max_sun IS NULL OR max_sun>=?)";
		SqlRowSet results= jdbcTemplate.queryForRowSet(sqlSelectPlantByPlotDetails, regionId, sunExposure, sunExposure);
		Plant plant = null;
		while(results.next()) {
			plant = createPlantObject(results);
			plantList.add(plant);
		}
		return plantList;
	}

	@Override
	public List<Plant> getPlantsByRegion(Long regionId) {
		List <Plant> plantList = new ArrayList<Plant>();
		String sqlSelectPlantByPlotDetails = "SELECT * " +
											"FROM plant " +
											"JOIN plant_region ON plant.plant_id= plant_region.plant_id " +
											"JOIN region ON plant_region.region_id = region.region_id " +
											"JOIN plant_types ON plant_types.plant_type=plant.plant_type "+
											"WHERE plant_region.region_id= ?" ;
		SqlRowSet results= jdbcTemplate.queryForRowSet(sqlSelectPlantByPlotDetails, regionId);
		Plant plant = null;
		while(results.next()) {
			plant = createPlantObject(results);
			plantList.add(plant);
		}
		return plantList;
	}

	@Override
	public Plant searchPlantByName(String commonName) {
		String sqlSelectPlantByName= "SELECT * " +
									"FROM plant " +
									"WHERE common_name=?";
		SqlRowSet results= jdbcTemplate.queryForRowSet(sqlSelectPlantByName, commonName);
		Plant plant = null;
		if(results.next()) {
			plant = createPlantObject(results);
		}
		return plant;
	}

	@Override
	public void createNewPlantEntry(String botanicalName, String commonName, int plantType, int spaceNeeded, int height, int minSun, int maxSun, int regionId) {
		Long id= getNextId();
		String sqlNewPlantEntry = "INSERT INTO plant(plant_id, botanical_name, common_name, plant_type, spread, height, min_sun, max_sun) "+
									"VALUES(?,?,?,?,?,?,?,?)";
		
		String sqlNewPlantRegion= "INSERT INTO plant_region (plant_id, region_id) " +
									"VALUES(?, ?)";
		
		jdbcTemplate.update(sqlNewPlantEntry, id, botanicalName, commonName, plantType, spaceNeeded, height, minSun, maxSun);
		jdbcTemplate.update(sqlNewPlantRegion, id, regionId);
		
	}

	@Override
	public void updatePlantEntry(String botanicalName, String commonName, int plantType, int spaceNeeded, int height,
			int minSun, int maxSun, int regionId) {
		
		String sqlUpdatePlant= "UPDATE plant SET botanical_name=?, common_name=?, plant_type=?, spread=?, height=?, min_sun=?, max_sun=? WHERE common_name=?";
		String sqlUpdatePlantRegion= "UPDATE plant_region SET region_id=? WHERE plant_id=?";
		
		jdbcTemplate.update(sqlUpdatePlant, botanicalName, commonName, plantType, spaceNeeded, height, minSun, maxSun);
		jdbcTemplate.update(sqlUpdatePlantRegion, regionId);
	}
	
	@Override
	public Plant getPlantById(long plantId) {
		String sqlGetPlantById = "SELECT * " +
								"FROM plant " +
								"JOIN plant_region ON plant.plant_id=plant_region.plant_id "+
								"JOIN region ON plant_region.region_id = region.region_id " +
								"JOIN plant_types ON plant_types.plant_type=plant.plant_type "+
								"WHERE plant.plant_id=?";
		SqlRowSet results = jdbcTemplate.queryForRowSet(sqlGetPlantById, plantId);
		Plant plant = null;
		if(results.next()) {
			plant = createPlantObject(results);
		}
		return plant;
	}

	@Override
	public int getPrice(long plantId) {
		int price = 0;
		String sqlGetPlantPrice = "SELECT price"
							      + " FROM plant"
							      + " JOIN plant_types"
							      + " ON plant.plant_type = plant_types.plant_type"
							      + " WHERE plant.plant_id = ?";
		SqlRowSet results = jdbcTemplate.queryForRowSet(sqlGetPlantPrice, plantId);
		if(results.next()) {
			Plant plant = new Plant();
			plant.setPrice(results.getInt("price"));
		}
		return price;
	}
	
	private Long getNextId() {
		String sqlSelectNextId = "SELECT NEXTVAL('plant_plant_id_seq')";
		SqlRowSet results = jdbcTemplate.queryForRowSet(sqlSelectNextId);
		Long id = null;
		if(results.next()) {
			id = results.getLong(1);
		} else {
			throw new RuntimeException("Something strange happened, unable to select next forum post id from sequence");
		}
		return id;
	}
	
	private Plant createPlantObject(SqlRowSet results) {
		Plant plant = new Plant();
		plant.setPlantId(results.getInt("plant_id"));
		plant.setBotanicalName(results.getString("botanical_name"));
		plant.setCommonName(results.getString("common_name"));
		plant.setHeight(results.getInt("height"));
		plant.setMinSun(results.getInt("min_sun"));
		plant.setMaxSun(results.getInt("max_sun"));
		plant.setPlantType(results.getString("type_description"));
		plant.setRegion(results.getString("region_name"));
		plant.setSpaceNeeded(results.getInt("spread"));
		plant.setPrice(results.getDouble("price"));
		return plant;
	}
}