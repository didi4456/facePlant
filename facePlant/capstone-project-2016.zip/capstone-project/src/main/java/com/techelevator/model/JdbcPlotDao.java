package com.techelevator.model;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;

@Component
public class JdbcPlotDao implements PlotDao {

	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public JdbcPlotDao(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public List<Plot> getPlotsByUserId(long appUserId) {
		List<Plot> plotList = new ArrayList<Plot>();
		String sqlGetAllUserPlots = "SELECT * " +
									"FROM plot p " +
									"JOIN appUser_plot up ON p.plotId=up.plotId " +
									"JOIN region r ON r.region_id=p.region_id " +
									"WHERE up.appUserId=?";
		SqlRowSet results = jdbcTemplate.queryForRowSet(sqlGetAllUserPlots, appUserId);
		while(results.next()) {
			Plot plot = createPlotObject(results);
			plotList.add(plot);
			plot.setRegionName(results.getString("region_name"));
		}
		return plotList;
	}

	@Override
	public void createNewPlotForUserId(long appUserId, String name, long regionId, int sunExposure, int height, int width) {
		Long plotId = getNextId("SELECT NEXTVAL('seq_plotId')");
		
		String sqlCreateNewPlot = "INSERT INTO plot (plotId, name, region_id, sunExposure, height, width) VALUES (?,?,?,?,?,?)";
		jdbcTemplate.update(sqlCreateNewPlot, plotId, name, regionId, sunExposure, height, width);
		
		String sqlCreateNewUserPlot = "INSERT INTO appUser_plot (appUserId, plotId) VALUES (?,?)";
		jdbcTemplate.update(sqlCreateNewUserPlot, appUserId, plotId);

		// create squares from height and width and fill plot_square table
		for(int col=0; col<height; col++) {
			for(int row=0; row<height; row++) {
				long squareId = getNextId("SELECT NEXTVAL('seq_squareId')");
				String sqlCreateNewSquare = "INSERT INTO square (squareId) VALUES (?)";
				jdbcTemplate.update(sqlCreateNewSquare, squareId);
				String sqlCreateNewPlotSquare = "INSERT INTO plot_square (plotId, squareId) VALUES (?,?)";
				jdbcTemplate.update(sqlCreateNewPlotSquare, plotId, squareId);
			}
		}
	}

	@Override
	public Plot getPlotById(long plotId) {
		String sqlGetPlotById = "SELECT * " +
								"FROM plot " +
								"WHERE plotId=?";
		SqlRowSet results = jdbcTemplate.queryForRowSet(sqlGetPlotById, plotId);
		Plot plot = null;
		if(results.next()) {
			plot = createPlotObject(results);
		}
		return plot;
	}

	private Plot createPlotObject(SqlRowSet results) {
		Plot plot = new Plot();
		plot.setId(results.getLong("plotId"));
		plot.setPlotName(results.getString("name"));
		plot.setRegion(results.getInt("region_id"));
		plot.setSunExposure(results.getInt("sunExposure"));
		plot.setPlotHeight(results.getInt("height"));
		plot.setPlotWidth(results.getInt("width"));
		
		List<Square> squareList = createSquareObjectsForPlot(plot);
		plot.setSquareList(squareList);
		
		return plot;
	}

	private List<Square> createSquareObjectsForPlot(Plot plot) {
		String sqlGetPlotSquares =	"SELECT * " +
									"FROM square s " +
									"JOIN plot_square ps ON s.squareId=ps.squareId " +
									"JOIN plot p ON ps.plotId=p.plotId " +
									//"JOIN plant pl ON s.plantId=pl.plant_id " +
									"WHERE p.plotId=?";
		SqlRowSet results = jdbcTemplate.queryForRowSet(sqlGetPlotSquares, plot.getId());
		List<Square> squareList = new ArrayList<Square>();
		while(results.next()) {
			Square square = new Square();
			square.setSquareId(results.getLong("squareId"));
			//square.setPlantContained(results.getString("common_name"));
			squareList.add(square);
		}
		return squareList;
	}
	
	private Long getNextId(String sqlSelectNextId) {
		SqlRowSet results = jdbcTemplate.queryForRowSet(sqlSelectNextId);
		Long id = null;
		if(results.next()) {
			id = results.getLong(1);
		} else {
			throw new RuntimeException("Something strange happened, unable to select next forum post id from sequence");
		}
		return id;
	}
}