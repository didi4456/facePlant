package com.techelevator.model;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;

@Component
public class JdbcSquareDao implements SquareDao {

	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public JdbcSquareDao(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public Square getSquareById(long squareId) {
		Square square = null;
		String sqlGetSquareById = 	"SELECT * " +
									"FROM square s " +
									"LEFT JOIN plant p ON s.plantId=p.plant_id " +
									"WHERE squareId=?";
		SqlRowSet results = jdbcTemplate.queryForRowSet(sqlGetSquareById, squareId);
		if(results.next()) {
			square = new Square();
			square.setSquareId(squareId);
			square.setPlantContained(results.getString("common_name"));
		}
		return square;
	}

	@Override
	public void addPlantToSquare(long squareId, long plantId) {
		String sqlAddPlantToSquare = "UPDATE square SET plantId=? WHERE squareId=?";
		jdbcTemplate.update(sqlAddPlantToSquare, plantId, squareId);
	}

	@Override
	public void emptySquare(long squareId) {
		String sqlEmptySquare = "UPDATE square SET plantId=NULL WHERE squareId=?";
		jdbcTemplate.update(sqlEmptySquare, squareId);
	}

}
