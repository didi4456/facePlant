package com.techelevator.model;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;

@Component
public class JdbcUserDao implements UserDao {

	private JdbcTemplate jdbcTemplate;

	@Autowired
	public JdbcUserDao(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public boolean searchForUsernameAndPassword(String username, String password) {
		String sqlSelectUserByUsername = "SELECT * " +
										"FROM appUser " +
										"WHERE username=? AND password=?";
		SqlRowSet results = jdbcTemplate.queryForRowSet(sqlSelectUserByUsername, username, password);
		return results.next();
	}

	@Override
	public void createNewUser(String username, String password, String email, boolean isSystemAdmin) {
		Long id = getNextId();
		String sqlNewUser = "INSERT INTO appUser(appUserId, username, password, email, isSystemAdmin) VALUES(?,?,?,?,?)";
		jdbcTemplate.update(sqlNewUser, id, username, password, email, isSystemAdmin);
	}

	@Override
	public User getUserByUsername(String username) {
		String sqlSelectUserByUsername = "SELECT * " +
										"FROM appUser " +
										"WHERE username=?";
		SqlRowSet results = jdbcTemplate.queryForRowSet(sqlSelectUserByUsername, username);
		User user = null;
		if(results.next()) {
			user = createUserObject(results);
		}
		return user;
	}
	
	@Override
	public User getUserById(long id) {
		String sqlSelectUserByUsername = "SELECT * " +
										"FROM appUser " +
										"WHERE appUserId=?";
		SqlRowSet results = jdbcTemplate.queryForRowSet(sqlSelectUserByUsername, id);
		User user = null;
		if(results.next()) {
			user = createUserObject(results);
		}
		return user;
	}
	
	private Long getNextId() {
		String sqlSelectNextId = "SELECT NEXTVAL('seq_appUserId')";
		SqlRowSet results = jdbcTemplate.queryForRowSet(sqlSelectNextId);
		Long id = null;
		if(results.next()) {
			id = results.getLong(1);
		} else {
			throw new RuntimeException("Something strange happened, unable to select next forum post id from sequence");
		}
		return id;
	}
	
	private User createUserObject(SqlRowSet results) {
		User user;
		user = new User();
		user.setUsername(results.getString("username"));
		//user.setPassword(results.getString("password")); no password for security?
		user.setId(results.getLong("appUserId"));
		user.setEmail(results.getString("email"));
		user.setSystemAdmin(results.getBoolean("isSystemAdmin"));
		return user;
	}

}