package com.techelevator.model;

public class Plant {

	private String botanicalName;
	private String commonName;
	private String plantType;
	private String region;
	private int plantId;
	private int spaceNeeded; //need to divide spread in database by 12 to get ft
	private int minSun; //may need to change from int
	private int maxSun;
	private int height;
	private double price;
	
	public String getBotanicalName() {
		return botanicalName;
	}
	public String getCommonName() {
		return commonName;
	}
	public String getPlantType() {
		return plantType;
	}
	public String getRegion() {
		return region;
	}
	public int getPlantId() {
		return plantId;
	}
	public int getSpaceNeeded() {
		return spaceNeeded;
	}
	public int getMinSun() {
		return minSun;
	}
	public int getMaxSun() {
		return maxSun;
	}
	public int getHeight() {
		return height;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getPriceString() {
		return "$"+(int)price+".00";
	}
	public void setBotanicalName(String botanicalName) {
		this.botanicalName = botanicalName;
	}
	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}
	public void setPlantType(String plantType) {
		this.plantType = plantType;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public void setPlantId(int plantId) {
		this.plantId = plantId;
	}
	public void setSpaceNeeded(int spaceNeeded) {
		this.spaceNeeded = spaceNeeded;
	}
	public void setMinSun(int minSun) {
		this.minSun = minSun;
	}
	public void setMaxSun(int maxSun) {
		this.maxSun = maxSun;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	
}