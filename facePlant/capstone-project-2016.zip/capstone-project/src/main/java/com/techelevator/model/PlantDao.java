package com.techelevator.model;

import java.util.List;

public interface PlantDao {

	public List<Plant> getPlantRecommendationByPlotDetails(Long regionId, int sunExposure);
	public List<Plant> getPlantsByRegion(Long regionId);
	public void createNewPlantEntry (String botannicalName, String commonName, int plantType, int spaceNeeded, int height, int minSun, int maxSun, int regionId);
	public Plant searchPlantByName(String commonName);
	public void updatePlantEntry (String botannicalName, String commonName, int plantType, int spaceNeeded, int height, int minSun, int maxSun, int regionId);
	public Plant getPlantById(long plantId);
	public int getPrice(long plantId);
}
