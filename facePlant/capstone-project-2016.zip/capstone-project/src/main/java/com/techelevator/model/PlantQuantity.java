package com.techelevator.model;

public class PlantQuantity {
	
		private Plant plant;
		private int quantity;
		
		public PlantQuantity(Plant plant, int quantity) {
			this.plant = plant;
			this.quantity = quantity;
		}

		public Plant getPlant() {
			return plant;
		}

		public void setPlant(Plant plant) {
			this.plant = plant;
		}

		public int getQuantity() {
			return quantity;
		}

		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		
		public double getPlantQuantityCost() {
			int priceInPennies = (int)(plant.getPrice()*100);
			priceInPennies = priceInPennies * quantity;
			return priceInPennies/100;
		}

		public String getPlantQuantityCostString() {
			double cost = getPlantQuantityCost();
			return "$"+(int)cost+".00";
		}
}
