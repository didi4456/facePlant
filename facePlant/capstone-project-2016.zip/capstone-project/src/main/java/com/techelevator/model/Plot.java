package com.techelevator.model;

import java.util.List;

public class Plot {

	private long id;
	private String plotName;
	private long region;
	private String regionName;
	private int sunExposure;
	private int plotHeight;
	private int plotWidth;
	private static double mulch;
	private static double topsoil;
	private int depthInInches;
	private static int bagsOfMulch;
	private static int bagsOfTopsoil;
	
	private String owner;
	private List<Square> squareList;
	
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public List<Square> getSquareList() {
		return squareList;
	}
	public void setSquareList(List<Square> squareList) {
		this.squareList = squareList;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getPlotName() {
		return plotName;
	}
	public void setPlotName(String plotName) {
		this.plotName = plotName;
	}
	public long getRegion() {
		return region;
	}
	public void setRegion(int region) {
		this.region = region;
	}
	public String getRegionString() {
		String getRegionString = "";
		if(region == 1) {
			getRegionString = "Ohio Lakeshore";
		} else if(region == 2) {
			getRegionString = "Central Ohio";
		} else if(region == 3) {
			getRegionString = "Southern Ohio";
		} else {
			getRegionString = "Error: Value Not Found";
		} 
		return getRegionString;
	}
	public int getSunExposure() {
		return sunExposure;
	}
	public void setSunExposure(int sunExposure) {
		this.sunExposure = sunExposure;
	}
	public int getPlotHeight() {
		return plotHeight;
	}
	public void setPlotHeight(int plotHeight) {
		this.plotHeight = plotHeight;
	}
	public int getPlotWidth() {
		return plotWidth;
	}
	public void setPlotWidth(int plotWidth) {
		this.plotWidth = plotWidth;
	}
	public String getSunExposureString() {
		String sunExposureString = "";
		if(sunExposure == 0) {
			sunExposureString = "Full Shade";
		} else if(sunExposure == 1) {
			sunExposureString = "Part Sun/Part Shade";
		} else if(sunExposure == 2) {
			sunExposureString = "Full Sun";
		} else {
			sunExposureString = "Error: Value Not Found";
		}
		return sunExposureString;
	}
	public static double getMulch(int plotHeight, int plotWidth, int depthInInches) {
		double area= plotHeight*plotWidth;
		double coverage= area* depthInInches;
		mulch = (coverage/324)*27;
		return mulch;
	}
	public static double getTopsoil(int plotHeight, int plotWidth, int depthInInches) {
		double area= plotHeight*plotWidth;
		double coverage= area* depthInInches;
		topsoil = (coverage/324)*27;
		return topsoil;
	}
	public void setMulch(double mulch) {
		this.mulch = mulch;
	}
	public void setTopsoil(double topsoil) {
		this.topsoil = topsoil;
	}
	public int getDepthInInches() {
		return depthInInches;
	}
	public void setDepthInInches(int depthInInches) {
		this.depthInInches = depthInInches;
	}
	public static int getBagsOfMulch(double mulch) {
		int bagsOfMulch= (int)Math.ceil(mulch/2);
		return bagsOfMulch;
	}
	public void setNumberOfBags(int numberOfBags) {
		this.bagsOfMulch = numberOfBags;
	}
	public static int getBagsOfTopsoil(double topsoil) {
		int bagsOfTopsoil= (int) Math.ceil(topsoil/2);
		return (int)bagsOfTopsoil;
	}
	public void setBagsOfTopsoil(int bagsOfTopsoil) {
		this.bagsOfTopsoil = bagsOfTopsoil;
	}
	public String getRegionName() {
		return regionName;
	}
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
}