package com.techelevator.model;

import java.util.List;

public interface PlotDao {
	
	public List<Plot> getPlotsByUserId(long userId);
	public Plot getPlotById(long plotId);
	public void createNewPlotForUserId(long userId, String name, long regionId, int sunExposure, int height, int width);
}
