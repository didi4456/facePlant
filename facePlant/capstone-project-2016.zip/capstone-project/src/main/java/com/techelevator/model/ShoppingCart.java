package com.techelevator.model;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
	
	private List<PlantQuantity> plantsInCart;
	private int quantity;
	
	public ShoppingCart() {
		this.plantsInCart = new ArrayList<>();
	}
	
	public void addToCart(PlantQuantity newPlantQuantity) {
		PlantQuantity existingPlantQuantity = findPlantQuantityByCommonName(newPlantQuantity.getPlant().getCommonName());
		if(existingPlantQuantity==null) {
			plantsInCart.add(newPlantQuantity);
		} else {
			int quantity = existingPlantQuantity.getQuantity() + newPlantQuantity.getQuantity();
			updateQuantityInPlantQuantity(existingPlantQuantity, quantity);
		}
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public int getTotalPlantsInCart() { //come back to figure out count
		int totalPlantsInCart = 0;
		for(PlantQuantity p : plantsInCart) {
			totalPlantsInCart++;
		} 
		return totalPlantsInCart;
	}
	
	public double getShoppingCartTotalCost() {
		double totalCost = 0;
		for(PlantQuantity plantQuantity : plantsInCart) {
			totalCost += plantQuantity.getPlantQuantityCost();
		}
		return totalCost;
	}
	
	public String getShoppingCartTotalCostString() {
		double totalCost = getShoppingCartTotalCost();
		return "$"+(int)totalCost+".00";
	}

	public List<PlantQuantity> getPlantsInCart() {
		return plantsInCart;
	}

	public void setPlantsInCart(List<PlantQuantity> plantsInCart) {
		this.plantsInCart = plantsInCart;
	}
	
	public void updateQuantityInPlantQuantity(PlantQuantity plantQuantity, int quantity) {
		if(quantity==0) {
			plantsInCart.remove(plantQuantity);
		} else {
			plantQuantity.setQuantity(quantity);
		}
	}
	
	public PlantQuantity findPlantQuantityByCommonName(String commonName) {
		for(PlantQuantity plantQuantity : this.plantsInCart) {
			if(plantQuantity.getPlant().getCommonName().equals(commonName)) {
				return plantQuantity;
			}
		}
		return null;
	}

}
