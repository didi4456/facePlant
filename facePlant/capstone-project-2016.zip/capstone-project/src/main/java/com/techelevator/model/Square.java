package com.techelevator.model;

public class Square {

	private long squareId;
	private String plantContained;
	
	public long getSquareId() {
		return squareId;
	}
	public void setSquareId(long squareId) {
		this.squareId = squareId;
	}
	public String getPlantContained() {
		return plantContained;
	}
	public void setPlantContained(String plantContained) {
		this.plantContained = plantContained;
	}
	
}
