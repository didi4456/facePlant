package com.techelevator.model;

public interface SquareDao {

	public Square getSquareById(long squareId);
	public void addPlantToSquare(long squareId, long plantId);
	public void emptySquare(long squareId);
}
