package com.techelevator.model;

public interface UserDao {
	
	public boolean searchForUsernameAndPassword(String username, String password);
	public void createNewUser(String username, String password, String email, boolean isSystemAdmin);
	public User getUserByUsername(String username);
	public User getUserById(long id);
	
}
