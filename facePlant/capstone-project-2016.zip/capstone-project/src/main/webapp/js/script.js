$(document).ready(function () {
	
	//added jQuery functions
	$.fn.exists = function () {
	    return this.length !== 0;
	}
	
	// userPage animation
	$(".list-group-item").hover(
		function () {
			$(this).children(".hiddenPlotDetails").stop(false,true);
			$(this).children(".plotName").animate({
				height: "0"
			}, 100,"linear", function() {
				$(this).css("display","none");
				$(this).siblings(".hiddenPlotDetails").css("display","inline")
				$(this).siblings(".hiddenPlotDetails").animate({
					height: "100%"
				}, 100,"linear", function(){
					$(this).siblings(".plotName").css("display","none");
					$(this).css("display","inline");
				});
			});
		},
		function () {
			$(this).children(".plotName").stop(false,true);
			$(this).children(".hiddenPlotDetails").animate({
				height: "0"
			}, 100,"linear", function() {
				$(this).css("display","none");
				$(this).siblings(".plotName").css("display","inline")
				$(this).siblings(".plotName").animate({
					height: "100%"
				}, 100,"linear", function(){
					$(this).siblings(".hiddenPlotDetails").css("display","none");
					$(this).css("display","inline");
				});
			});
		}
	);
	
	$("#createNewPlot").hover(
		function(){
			$(this).children("#createNewPlotButton").stop(false,false);
			$(this).children("#createNewPlotButton").animate({
				fontSize: "70px"
			});
		},
		function(){
			$(this).children("#createNewPlotButton").stop(false,false);
			$(this).children("#createNewPlotButton").animate({
				fontSize: "20px"
			});
		});
	
	// applicationURL for ajax
	var applicationURL = "http://localhost:8080/capstone";
	
	// For navbar in header.jsp
	var pathname = window.location.pathname;
	$("nav a[href='"+pathname+"']").parent().addClass("active");
	
	$("#logoutLink").click(function(event){
		$("#logoutForm").submit();
	});
	
	// For userPage.jsp
	var $newPlotButton = $("#createNewPlot");
	var $hiddenForm = $("#hiddenForm");
	
	$newPlotButton.click(function () {
		$hiddenForm.toggle();
	});
	
	// For systemAdmin.jsp
	var $newPlantButton = $("#newPlantButton");
	$newPlantButton.click(function () {
		$("#systemAdminForms form").hide();
		$("#newPlantForm").show();
	});
	var $editPlantButton = $("#editPlantButton");
	$editPlantButton.click(function () {
		$("#systemAdminForms form").hide();
		$("#editPlantForm").show();
	});
	var $newAdminButton = $("#newAdminButton");
	$newAdminButton.click(function () {
		$("#systemAdminForms form").hide();
		$("#newAdminForm").show();
	});
	
	
	// For plotDetail.jsp
	
	loadPlantedImages();
	
	function loadPlantedImages() {
		$(".square").each(function() {
			var squareId = $(this).children("input").val();
			$.ajax({
			/* url : applicationURL+"/user/{username}/{plotId}/{squareId}" */
			url : applicationURL+"/user/"+$("#username").val()+"/"+$("#plotId").val()+"/"+squareId,
				type: "GET",
				dataType: "json"
			}).success(function (result) {
				applyImage(result);
			}).fail(function(xhr, status, errorMessage){
				console.log(errorMessage);
				console.log(status);
				console.log(xhr);
			});
		});
	}
	
	function applyImage(square) {
		if(square.plantContained==null) {
			$("#square_"+square.squareId).removeClass("plantedSquare");
			$("#square_"+square.squareId).addClass("unplantedSquare");
		} else {
			$("#square_"+square.squareId).removeClass("unplantedSquare");
			$("#square_"+square.squareId).addClass("plantedSquare");
		}
	}
	
	$(".square").hover(mouseIn, mouseOut);
	
	function mouseIn() {
		$(this).addClass("mouseOver");
		var squareId = $(this).children("input").val();
		$.ajax({
		/* url : applicationURL+"/user/{username}/{plotId}/{squareId}" */
		url : applicationURL+"/user/"+$("#username").val()+"/"+$("#plotId").val()+"/"+squareId,
			type: "GET",
			dataType: "json"
		}).success(function (result) {
			printSquareDetails(result);
		}).fail(function(xhr, status, errorMessage){
			console.log(errorMessage);
			console.log(status);
			console.log(xhr);
		});
		
		var $popUp = $(this).next(".squarePopupDetails");
		var rect = this.getBoundingClientRect();
		var absoluteLeft = parseFloat(rect.left);
		var absoluteTop = parseFloat(rect.bottom);
		
		$popUp.css("left", absoluteLeft);
		$popUp.css("top", absoluteTop);
		//$popUp.css("width",style.width);
		$popUp.show();
	}
	function mouseOut() {
		$(this).removeClass("mouseOver");
		$(this).next(".squarePopupDetails").children(".plantedHere").text("");
		$(this).next(".squarePopupDetails").hide();
	}
	function printSquareDetails(square) {
		if (square.plantContained==null) {
			$("#squareDetailsDiv_"+square.squareId).children(".plantedHere").html("<h3>Nothing planted yet!</h3><p>Click on a plant below and then click a square to plant it in.</p>");
			if($(".panel-primary").exists()) {
				var plantName = $(".panel-primary").children("#plantName").val();
				$("#squareDetailsDiv_"+square.squareId).children(".plantedHere").html("<h3>Nothing planted yet!</h3><p>Click here to plant "+plantName+".</p>");
			}
		} else {
			$("#squareDetailsDiv_"+square.squareId).children(".plantedHere").html("<h3>"+square.plantContained+"</h3><p>Double-click to remove it.</p>");
		}
	};
	
	$(".square").click(getSquareFromClick);
	
	function getSquareFromClick() {
		var squareId = $(this).children("input").val();
		$.ajax({
			/* url : applicationURL+"/user/{username}/{plotId}/{squareId}" */
			url : applicationURL+"/user/"+$("#username").val()+"/"+$("#plotId").val()+"/"+squareId,
				type: "GET",
				dataType: "json"
		}).success(function (result) {
			addPlant(result);
		}).fail(function(xhr, status, errorMessage){
			console.log(errorMessage);
			console.log(status);
			console.log(xhr);
		});
	}
	
	function addPlant(square) {
		if(square.plantContained==null) {
			if($(".panel-primary").exists()) {
				var plantId = $(".panel-primary").children("#plantId").val();
				$.ajax({
					url : applicationURL+"/user/"+$("#username").val()+"/"+$("#plotId").val()+"/"+square.squareId+"/"+plantId,
					type: "POST",
					dataType: "json"
				}).success(function (result) {
					printSquareDetails(result);
					applyImage(result);
				}).fail(function(xhr, status, errorMessage){
					console.log(errorMessage);
					console.log(status);
					console.log(xhr);
				});
			}
		}
	}
	
	$(".square").dblclick(emptySquare);
	
	function emptySquare() {
		var squareId = $(this).children("input").val();
		$.ajax({
			url : applicationURL+"/user/"+$("#username").val()+"/"+$("#plotId").val()+"/"+squareId+"/empty",
			type: "POST",
			dataType: "json"
		}).success(function (result) {
			printSquareDetails(result);
			applyImage(result);
		}).fail(function(xhr, status, errorMessage){
			console.log(errorMessage);
			console.log(status);
			console.log(xhr);
		});
	}
	
	// For plotDetails Rec Plants
	$(".recPlantDiv").hover(
		function () {
			if(!$(this).is(".panel-primary")) {
				$(this).addClass("panel-info");
			}
			$(".panel-body").not($(this).children(".panel-body")).hide();
			if($(this).is(".panel-primary")) {
				$(this).children(".panel-body").show();
			}
		},function () {
			$(this).removeClass("panel-info");
			$(this).children(".panel-body").hide();
	});
	
	$(".panel-heading").click(function () {
		$(".recPlantDiv").not($(this).parent()).removeClass("panel-primary");
		$(this).parent().removeClass("panel-info");
		$(this).parent().toggleClass("panel-primary");
		$(this).siblings(".panel-body").toggle();
	});
	
	/*
	var $recommendedPlantsDiv = $("#recommendedPlants");
	
	function printRecommendedPlants(plantList) {
		for(i=0; i<plantList.length; i++) {
			var $plantDiv = $("<div>");
			$plantDiv.html(plantList[i].commonName);
			$recommendedPlantsDiv.append($plantDiv);
		}
	}
	$.ajax({
		// url : applicationURL+"/user/{username}/{plotId}/recommendedPlants"
		url : applicationURL+"/user/"+$("#username").val()+"/"+$("#plotId").val()+"/recommendedPlants",
			type: "GET",
			dataType: "json"
	}).success(function (result) {
		printRecommendedPlants(result);
	}).fail(function(xhr, status, errorMessage){
		console.log(errorMessage);
		console.log(status);
		console.log(xhr);
	});
	*/
	
	// for ShoppingCart.jsp
	$(".itemQuantity").focus(function (){
		$(this).val($(this).attr("placeholder"));
	});
	
	$(".itemQuantity").blur(function (){
		if($(this).val() && $(this).val()!=$(this).attr("placeholder")) {
			$(this).parent().submit();
		}
	});
	
	$(".quantity").blur(function (){
		if(!$(this).val()) {
			$(this).val("1");
		}
	});
	
});