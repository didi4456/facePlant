package com.techelevator.cukes;

import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.techelevator.pageobject.LoginInputPage;
import com.techelevator.pageobject.LoginUserResult;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@Component
public class LoginSteps {
	
	private WebDriver webDriver;
	private LoginInputPage loginInputPage;
	private LoginUserResult loginUserResult;
	
	@Autowired
	public LoginSteps(WebDriver webDriver){
		this.webDriver= webDriver;
		this.loginInputPage= new LoginInputPage(webDriver);
		this.loginUserResult= new LoginUserResult(webDriver);
	}
	
	@Given("^I want to log into facePlant from the Login Page$")
	public void i_want_to_log_into_facePlant_from_the_Login_Page() throws Throwable {
		webDriver.get("http://localhost:8080/capstone/login");
	}

	@Given("^I provide correct username (\\w+)$")
	public void i_provide_a_correct_username(String username) throws Throwable {
	loginInputPage.enterUsername(username);
	}

	@Given("^I provide a correct password (\\w+)$")
	public void i_provide_a_correct_password(String password) throws Throwable {
	loginInputPage.enterPassword(password);
	}

	@When("^I click submit$")
	public void i_click_submit() throws Throwable {
	loginInputPage.submitForm();
	}

	@Then("^I will see my user landing page$")
	public void i_will_see_my_user_landing_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	

}
