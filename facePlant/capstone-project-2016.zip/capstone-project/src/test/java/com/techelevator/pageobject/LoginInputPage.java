package com.techelevator.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginInputPage {
	
	private WebDriver webDriver;
	
	public LoginInputPage (WebDriver webDriver) {
		this.webDriver=webDriver;
		
	}
	
	public LoginInputPage enterUsername(String username) {
		WebElement field= webDriver.findElement(By.id("username"));
		field.click();
		field.sendKeys(username);
		return this;
	}
	public LoginInputPage enterPassword(String password) {
		WebElement field= webDriver.findElement(By.id("password"));
		field.sendKeys(password);
		return this;
	}
	public LoginUserResult submitForm(){
		WebElement button = webDriver.findElement(By.id("loginbutton"));
		button.click();
		return new LoginUserResult(webDriver);
	}
}
