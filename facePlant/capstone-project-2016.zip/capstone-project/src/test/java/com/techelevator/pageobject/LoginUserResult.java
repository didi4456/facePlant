package com.techelevator.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginUserResult {
	
	private WebDriver webDriver;

	public LoginUserResult(WebDriver webDriver) {
		this.webDriver= webDriver;
	}
	
	public String getUsername(){
		return webDriver.findElement(By.id("username")).getText();
	}
	public String getPassword(){
		return webDriver.findElement(By.id("password")).getText();
	}

}
